<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Http\Request;

Route::get('/', function () {
    $books = App\Book::all();
    return view('welcome',compact('books'));
});

Route::post('/search', function (request $request) {
    $key_sreach = request()->key;
    $books = App\Book::query()
    ->where('title', 'LIKE', "%{$key_sreach}%") 
    ->get();
 
    return view('welcome',compact('books'));
});